# IPMA Level D — SAQ Revision Suite

Two linked, browser-based study tools for the **IPMA Level D** short-answer (SAQ) paper. No build step, no dependencies — open in any browser.

| File | Tool |
|------|------|
| `index.html` | **Flashcard drill** — active-recall cards with RAG mastery tracking and a "drill weak" mode |
| `exam.html` | **Live practice exam** — timed mock paper, self-marking against a 5-point scheme, results breakdown |

The two are cross-linked: the flashcards link to the exam, and the exam links back to the flashcards (including a "revisit" prompt on your results).

## Scope

Covers the 14 competence elements in the revision materials, mapped to ICB4 KCIs:

- **Perspective** — 4.3.2 Governance/structures/processes · 4.3.4 Power & interest · 4.3.5 Culture & values
- **People** — 4.4.4 Relationships & engagement · 4.4.5 Leadership · 4.4.6 Teamwork · 4.4.7 Conflict & crisis · 4.4.8 Resourcefulness
- **Practice** — 4.5.4 Time · 4.5.5 Organisation & Information · 4.5.6 Quality · 4.5.7 Finance · 4.5.8 Resources · 4.5.12 Stakeholders

## Exam tool

- **Full mock** — 14 questions (one per competence element), 120-minute countdown, answer any 12, pass at 36/60 (60%).
- **Practice bank** — 43 questions filterable by area and difficulty (easy → tough).
- **Self-marking** — reveals a model answer plus a 5-point mark scheme; tick the points you covered.
- **Results** — percentage, pass/fail, breakdown by area, and a list of competences to revisit.

## Flashcard tool

- Flip to reveal the model answer (`Space`), rate yourself Review / Almost / Mastered (`1` `2` `3`).
- **Drill weak** filters to everything not yet mastered; progress persists in the browser.
- Filter by topic, shuffle, and navigate with the arrow keys.

## Run locally

Open `index.html` (start with the flashcards) or `exam.html` directly.

## Publish to GitHub Pages

After creating an **empty** repo on GitHub (no README/licence — this repo already has them):

```bash
git remote add origin https://github.com/<your-username>/<repo>.git
git branch -M main
git push -u origin main
```

Then: **Settings → Pages → Source: Deploy from a branch → Branch: `main` / `root` → Save.**

Live at `https://<your-username>.github.io/<repo>/` — flashcards at the root, exam at `/exam.html`.

## Note on content

Revision material derived from the ICB4 syllabus for personal exam preparation. It is a study aid, not an official IPMA publication or mark scheme.
